$(function(){
  var video = $('video')[0];
  
  // Play Button
  $('#play').click(function(){
    video.play();
  })
  
  // Pause Button
  $('#pause').click(function(){
    video.pause();
  });
  
  // Stop
  $('#stop').click(function(){
    video.pause();
    video.currentTime = 0;
  })
  
  // Skip Back
  $('#skipBack').click(function(){
    video.currentTime -= 2;
  })
  
  $(video).bind('loadedmetadata', function(){
    var seek = $('#seek'), 
        paused;
    
    // Set up Slider
    seek.slider({
      min: 0,
      max: video.duration,
      stop: function(event, ui){
        video.currentTime = ui.value;
        if(!paused){
          video.play();
        }
      },
      start: function(event, ui){
        paused = video.paused;
        video.pause();
      }
    });
    
    $(video).bind('timeupdate', function(){
      seek.slider('value', video.currentTime)
    })
    
  })
  
  
})