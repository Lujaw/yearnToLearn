(function($){
  $.fn.autosave = function(prefix){
    var storage = localStorage; // or sessionStorage
    var $this = $(this);
    
    if(!prefix){ prefix = $this.attr('id'); }
    prefix += ">"; // Separate prefix from input name;
    
    
    
    function save(){
      console.log('save')
      $this.find('input:not(:password, :submit)').each(function(index, element){
        var key = prefix + element.name;
        storage.setItem(key, $(element).val());
      })
      
    };
    
    function restore(){
      var i, key, value, name;
      for(i=0; i < storage.length; i++){
        key = storage.key(i);

        if(0 === key.indexOf(prefix)){    
          value = storage.getItem(key);
          name = key.replace(prefix, '');
          
          $this.find('[name='+name+']').val(value);
        }
      }
    };
    
    function clear(e){
      var keys = [], i, key;


      // Collect Keys;
      for(i=0; i < storage.length; i++){
        key = storage.key(i);
        if(0 === key.indexOf(prefix)){
          keys.push(key);
        }
      }
      
      // Remove Each Key
      for(i=0; i < keys.length; i++ ){
        storage.removeItem(keys[i]);
      }

    };
    
    
    $this.change(save);
    $this.submit(clear);
    
    restore();
    
    console.log('DONE')
  }
  
  
})(jQuery);