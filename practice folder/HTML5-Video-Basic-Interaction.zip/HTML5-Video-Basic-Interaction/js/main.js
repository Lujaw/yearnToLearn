$(function(){
  var video = $('video')[0];
  
  // Play Button
  $('#play').click(function(){
    video.play();
  });
  
  // Pause Button
  $('#pause').click(function(){
    video.pause();
  });
  
  // Stop
  $('#stop').click(function(){
    video.pause();
    video.currentTime = 0;
  });
  
  // Skip Back
  $('#skipBack').click(function(){
    video.currentTime -= 2;
  });
})